# __init__.py

__version__ = "0.1.98"

__all__ = ['funnelplot', 'funnelpy', 'sigmas']

# from .funnelpy import funnelpy