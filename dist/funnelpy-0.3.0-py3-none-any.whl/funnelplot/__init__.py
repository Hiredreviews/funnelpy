# __init__.py

__version__ = "0.1.98"

name = 'funnelplot'

from .funnelpy import funnelplot